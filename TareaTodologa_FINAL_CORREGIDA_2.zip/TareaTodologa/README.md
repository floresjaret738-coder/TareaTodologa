# Tarea Todóloga — iOS

Proyecto SwiftUI para iOS 17+ preparado para:

**GitHub → Codemagic → Signing Ad Hoc → Release Archive → IPA → ESign**

## GitHub

Sube el contenido de `TareaTodologa/` a un repositorio. No incluyas certificados `.p12`, perfiles `.mobileprovision`, API keys ni contraseñas.

Bundle Identifier:

`com.tareatodologa.app`

El Team ID, certificado y provisioning profile permanecen fuera del repositorio.

## Codemagic

En Codemagic, en **Code signing identities**, carga:

- un certificado de distribución iOS válido para Ad Hoc;
- un provisioning profile Ad Hoc para `com.tareatodologa.app`.

El archivo `codemagic.yaml` usa exclusivamente:

- `distribution_type: ad_hoc`;
- `bundle_identifier: com.tareatodologa.app`;
- `xcode-project use-profiles`;
- `xcode-project build-ipa`.

No se almacenan certificados, perfiles, contraseñas ni claves privadas en el repositorio.

## Build

Selecciona el workflow `ios-adhoc`.

El proyecto es:

`TareaTodologa.xcodeproj`

El scheme compartido es:

`TareaTodologa`

El Archive se realiza con `Release` y la exportación es Ad Hoc. La IPA se publica como artifact en:

`build/ios/ipa/*.ipa`

`xcode-project use-profiles` aplica durante el build los perfiles/certificados Ad Hoc administrados por Codemagic.

## ESign

Descarga la IPA Ad Hoc desde los artifacts de Codemagic y úsala con ESign.

Una IPA Ad Hoc solo puede instalarse en dispositivos cuyo UDID esté incluido en el provisioning profile con el que se firmó la aplicación.

## GitHub Actions

El workflow de GitHub Actions sirve como **validación de compilación**, no como sistema principal de firma.

Sin certificados ni perfiles ejecuta un Archive Release sin firma usando:

`CODE_SIGNING_ALLOWED=NO`

`CODE_SIGNING_REQUIRED=NO`

No necesita secrets para validar que el proyecto compile.

La firma Ad Hoc se realiza en Codemagic, que administra el certificado y provisioning profile fuera del repositorio.

## Configuración de signing

Debug usa signing automático para facilitar ejecución/desarrollo local.

Release usa signing manual, porque es la configuración destinada al Archive Ad Hoc de Codemagic. `xcode-project use-profiles` aplica el Team ID, certificado y provisioning profile disponibles en Codemagic antes del Archive.

No se incluyen en el proyecto:

- Team ID privado;
- certificados;
- archivos `.mobileprovision`;
- contraseñas;
- API keys.

## IA

La app no contiene API keys de proveedores.

Sin endpoint configurado utiliza `MockAIService`.

`RemoteAIService` está preparado para un backend HTTPS propio y envía:

- `question`
- `subject`
- `level`
- `ocrItems`
- `imageBase64JPEG` opcional

La respuesta esperada contiene:

- `question`
- `subject`
- `finalAnswer`
- `summary`
- `steps`
- `why`
- `easyExplanation`
- `directExplanation`
- `annotations`

## Privacidad

Las imágenes se guardan localmente solo cuando el usuario activa `Guardar imágenes localmente`. No se envían imágenes al backend salvo que el usuario active `Permitir enviar imágenes`.
